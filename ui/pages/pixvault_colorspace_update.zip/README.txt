PixVault Color Space Page — UI Integration
==========================================

1. Replace ui/pages/colorspace_page.py with colorspace_page.py.
2. Leave ui/styles/pixvault_theme.py unchanged. The page uses role() and
   apply_page_theme() from that module.
3. The existing ui/components/processing_options/colorspace_options.py is
   compatible; no extra component replacement is required.

Page layout matches ConvertPage:
- Hero and format support
- 01 Import & Organize
- Preview and image details (6:4)
- 02 Configure Color Space and output selection (6:5)
- 03 Process & Export (progress and cancellation)
- Responsive widths: 960px and 620px

Current backend limitations:
- Adobe RGB / Display P3 / CMYK controls are visible but disabled because
  processing/colorspace.py does not have valid destination ICC profiles.
- sRGB conversion of grayscale or indexed originals may fail: the current
  ImageCms transform requires an RGB/RGBA-compatible input mode.
- The existing JPEG encoder writes grayscale image pixels in RGB mode;
  PNG/TIFF are preferred for single-channel grayscale output.
- Color conversion does not guarantee full ICC fidelity, metadata retention,
  or alpha preservation in every output format. For accurate color-managed
  workflows, the underlying processors/encoders require additional work.

Verification:
- Python syntax check: passed.
- Existing pipeline tested with RGB->sRGB (JPEG/PNG), RGBA->sRGB (PNG),
  and RGB->Grayscale (PNG/TIFF/JPEG); JPEG remains RGB-encoded.
- GUI runtime not tested because PySide6 is unavailable in this environment.
