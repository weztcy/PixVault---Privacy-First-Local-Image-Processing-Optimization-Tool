PixVault DPI Page Update
========================

1. Replace ui/pages/dpi_page.py with ui/pages/dpi_page.py from this bundle.
2. Replace ui/styles/pixvault_theme.py with ui/styles/pixvault_theme.py
   (the existing theme with added opt-in QSpinBox and QCheckBox roles).
3. To ensure exported DPI values are physically saved in JPEG/PNG/TIFF:
   apply dpi_encoder_support.patch at the root of the original project:
       git apply dpi_encoder_support.patch
   (Alternatively use `patch -p1 < dpi_encoder_support.patch`.)

   If you've already modified formats/jpeg.py, png.py or tiff.py,
   review the patch before applying it.

Notes
-----
- Same as source supports JPEG/PNG/TIFF only and requires a uniform
  format across the batch because the pipeline takes one output format.
- The original DPIOptions remains in use. Its linked state is sent to
  the DPIProcessor so separate horizontal/vertical resolution is respected.
- Pixel dimensions do not change with DPI operations.
- Qt GUI runtime was not tested (PySide6 not installed in this environment).
