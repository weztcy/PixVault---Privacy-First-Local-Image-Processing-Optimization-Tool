PixVault page refactor: Bit Depth and Color Space
=================================================

Installation
------------
1. Replace ui/pages/bitdepth_page.py with bitdepth_page.py.
2. Replace ui/pages/colorspace_page.py with colorspace_page.py if you
   also want the corresponding Color Space page refactor.
3. Keep ui/styles/pixvault_theme.py unchanged. Both pages use role() and
   apply_page_theme() from that module.
4. Existing reusable controls must remain in ui/components/.

Functionality and limitations
-----------------------------
Bit Depth:
- PNG/TIFF outputs; 'Same as source' only for homogeneous PNG/TIFF inputs.
- 8-bit output works using existing encoders.
- 16-bit export is limited to 8-bit grayscale (PIL mode L) input.
  It creates a 16-bit output container, not new source precision.
- 16-bit RGB and 32-bit output are not supported by existing encoders.
- Output configuration includes format, suffix, bit_depth and grayscale
  encoder options, avoiding the old output={'keep_format': True} error.

Color Space:
- Uses the existing ColorSpaceOptions panel and theme roles.
- Offers sRGB and Grayscale only; Adobe RGB, Display P3 and CMYK
  require additional reliable ICC-profile backend support.
- The color-space conversion processor/encoders are not changed here.

Testing
-------
- Both Python page files pass syntax compilation.
- Back-end pipeline checked for PNG/TIFF 8-bit, grayscale 16-bit,
  PNG grayscale and JPEG sRGB output using Pillow.
- Full PySide6 GUI integration needs to be tested on the target desktop.

This archive deliberately does not overwrite processing/ or formats/.
